/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WarClass;

/**
 *
 * @author Wislo
 */
public class MatchRecord {
    
    //private Player winner, loser;
    private int warCounter, wonWarsW, wonWarsL, drawnCardsW, drawnCardsL,
                wonExchangeW, wonExchangeL;
    private Card wonWith; //instead of objects, an id or sth to get the image, things, etc.
    //image icons for players
    private String winnerName, loserName, gameType;
    //match duration

    public MatchRecord(Player winner, Player loser, int warCounter, String gameType) {
        this.winnerName = winner.getName();
        this.loserName = loser.getName();
        this.warCounter = warCounter;
        this.gameType = gameType;
    }
    
    
    
    
    
    
}
