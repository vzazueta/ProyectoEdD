/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinalestructuradedatos;

import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class WarFrame {
    
    public WarFrame() throws IOException{
        init();
    }
    
    public static void init() throws IOException{
        JFrame tablero = new JFrame();
                Deck baraja = new Deck(); 
                /*
                Not able to submit breakpoint MethodBreakpoint [proyectofinalestructuradedatos.Deck].Deck 
                '(Ljava/lang/String;)V', reason: Method '<init>' with signature '(Ljava/lang/String;)V' 
                does not exist in class proyectofinalestructuradedatos.Deck.
                                           */
        JPanel centro = new JPanel(),
               player1 = new JPanel(),
               player2 = new JPanel();
        tablero.setBounds(0, 0, 800, 600);

        //tablero.pack();
  
        centro.setBounds(0, 0, 150, 100);
        player1.setBounds(0, 0, 150, 100);
        player2.setBounds(0, 0, 150, 100);
        
        player1.add(new JLabel(new ImageIcon(baraja.getCard().getFace())));
        player2.add(new JLabel(new ImageIcon(baraja.getCard().getFace())));
        
        
        
        tablero.add(centro);
        tablero.add(player1);
        tablero.add(player2);
        
        
        tablero.setLocationRelativeTo(null); // Center the tablero
        tablero.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tablero.setVisible(true);
    }
}
