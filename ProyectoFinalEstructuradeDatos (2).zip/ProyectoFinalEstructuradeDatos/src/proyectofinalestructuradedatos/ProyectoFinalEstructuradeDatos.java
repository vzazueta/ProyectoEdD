
package proyectofinalestructuradedatos;

import java.io.IOException;
//import javax.swing.JFrame;

public class ProyectoFinalEstructuradeDatos {

    public static void main(String[] args) throws IOException{
        
        Deck deck = new Deck();
        WarFrame gui = new WarFrame();
    }
    
}
