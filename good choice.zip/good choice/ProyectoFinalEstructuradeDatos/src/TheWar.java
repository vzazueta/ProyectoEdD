/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.EmptyStackException;
import java.util.Stack;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;


class BoardNode implements Comparator <BoardNode>{
    
    private Card card;
    private Player player;
    
    public BoardNode(){} //For Comparator purposes
    
    public BoardNode(Card card, Player player) throws EmptyStackException{
        
        if(card!=null){
            this.card = card;
            this.player = player;
        }
        
        else{
            throw new EmptyStackException();
        }
        
    }
    
    public Card getCard(){
        return this.card;
    }
    
    public Player getPlayer(){
        return this.player;
    }
    
    @Override
    public int compare(BoardNode a, BoardNode b) {
        return a.card.getRank()-b.card.getRank();
    }
    
}

public class TheWar extends javax.swing.JPanel{
    
    private WarFrame gui;
    private GameManager manager;
    private Stack <Card> deck;
    private Stack <BoardNode> miniStackA, miniStackB;
    private Player player1, player2, prevWinner;
    private ArrayList<BoardNode> BOARD;
    private int turn,warMult,warCounter,x1,y1,x2,y2,rem1,rem2;
    private boolean warMode,cpu ,canWin, halfDeck,active1, active2;
    private String results, startTime, finishTime, startDate, finishDate;
    private ImageIcon background, cardBack,warBG,regBG;
    private Timer tm , tm2 , tm3 , tm4;
    private Card current1, current2;
    
    /**
     * Creates new form TheWar
     */
    public TheWar(WarFrame gui, GameManager manager) {
        this.initComponents();
        this.enableListeners();
        this.setFocusable(true);
        this.requestFocusInWindow();
        this.cardBack = manager.getCardBack();
        this.hideUIElements();
        this.gui = gui;
        this.manager = manager;
        this.regBG = new ImageIcon("basic_green.png");
        this.warBG = new ImageIcon("war_background.png");
        this.background = regBG; 
        this.deck = this.manager.getDeck().getDeck();
        this.player1 = this.manager.getPlayer1();
        this.player2 = this.manager.getPlayer2();
        this.BOARD = new ArrayList<>();
        this.miniStackA = new Stack<>();
        this.miniStackB = new Stack<>();
        this.cpu = this.manager.isCPU();
        this.halfDeck = this.manager.isHalfDeck();
        this.initGameVariables();
        
        this.lblPIcon1.setIcon(player1.getPlayerIcon());
        this.lblPIcon2.setIcon(player2.getPlayerIcon());
        
        
    }
    
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(background.getImage(), 0, 0, this);
    }
    
    private void enableListeners(){
        this.addKeyListener(new KeyListener(){
            
            @Override
            public void keyTyped(KeyEvent ke) {}
            
            @Override
            public void keyPressed(KeyEvent ke) {
                if(active1 && ke.getKeyCode() == KeyEvent.VK_S && !isCpu()){
                    actionPlayer1();
                }
                else if(active2 && ke.getKeyCode() == KeyEvent.VK_L && !isCpu()){
                    actionPlayer2();
                }
            }
            
            @Override
            public void keyReleased(KeyEvent ke) {}
            
        });
        
    }
    
    
    // MATCH INITIALIZATION METHODS //
    
    private void hideUIElements(){
        
        this.lblPIcon1.setVisible(false);
        this.lblPIcon2.setVisible(false);
        
        this.lblNameTag1.setVisible(false);
        this.lblNameTag2.setVisible(false);
        
        this.lblNameTag1.setVisible(false);
        this.lblNameTag2.setVisible(false);
        
        this.lblManyC1.setVisible(false);
        this.lblManyC2.setVisible(false);
        
        this.lblQty1.setVisible(false);
        this.lblQty2.setVisible(false);
        
        this.btnDraw1.setVisible(false);
        this.btnDraw2.setVisible(false);
        this.btnScore.setVisible(false);
        
        this.lblBoardDummy1.setVisible(false);
        this.lblBoardDummy2.setVisible(false);
        
        this.lblDrawDummy1.setVisible(false);
        this.lblDrawDummy2.setVisible(false);
        
        this.lblDiscardDummy1.setVisible(false);
        this.lblDiscardDummy2.setVisible(false);
        
        this.lblDrawDummy1.setIcon(cardBack);
        this.lblDrawDummy2.setIcon(cardBack);
        this.lblBoardDummy1.setIcon(cardBack);
        this.lblBoardDummy2.setIcon(cardBack);
        
        this.lblWarMsg1.setVisible(false);
        this.lblWarMsg2.setVisible(false);
        
        this.lblRemWarCards1.setVisible(false);
        this.lblRemWarCards2.setVisible(false);
        
        this.lblTake1.setVisible(false);
        this.lblTake2.setVisible(false);
        
        this.lblDrawCard1.setVisible(false);
        this.lblDrawCard2.setVisible(false);
        
        this.lblRepMsg1.setVisible(false);
        this.lblRepMsg2.setVisible(false);
        
        this.lblKey1.setVisible(false);
        this.lblKey2.setVisible(false);
        
        this.lblBigWinnerTag.setVisible(false);
        this.lblWins.setVisible(false);
        this.lblBigLoserTag.setVisible(false);
        this.lblOutOfCards.setVisible(false);
        
        this.btnPlayAgain.setVisible(false);
        this.btnRtrnMainMenu.setVisible(false);
        this.btnKeep.setVisible(false);
        this.btnGotoSetup.setVisible(false);
        this.btnMM.setVisible(false);
        
        
        
    }
    
    private void initGameVariables(){
        this.turn=-1;
        this.warMult=0;
        this.warMode = false;
        this.results=""; //tbr
        this.x1=574;
        this.y1 = 490;
        this.x2 = 574;
        this.y2 = 20;
        this.current1=null;
        this.current2=null;
        if(!isCpu()) this.btnDraw1.setEnabled(false);
    }
    
    private void showUIElements(){
        this.btnDeal.setVisible(false);
        
        this.btnMM.setIcon(new ImageIcon("back.png"));
        this.btnMM.setVisible(true);
        
        if(!cpu){
            this.lblKey1.setVisible(true);
            this.lblKey2.setVisible(true);
        }
        
        this.btnDraw1.setVisible(true);
        //this.btnDraw2.setVisible(true);
        
        this.lblDrawDummy1.setVisible(true);
        this.lblDrawDummy2.setVisible(true);
        
        this.lblDrawCard2.setIcon(cardBack);
        this.lblDrawCard1.setIcon(cardBack);
        
        this.lblDrawCard1.setVisible(true);
        this.lblDrawCard2.setVisible(true);
        
        this.lblNameTag1.setText(player1.getName());
        this.lblNameTag2.setText(player2.getName());
        this.lblNameTag1.setVisible(true);
        this.lblNameTag2.setVisible(true);
        
        this.lblRepMsg1.setVisible(true);
        this.lblRepMsg2.setVisible(true);
        
        this.lblNameTag1.setVisible(true);
        this.lblNameTag2.setVisible(true);
        
        this.lblManyC1.setVisible(true);
        this.lblManyC2.setVisible(true);
        
        this.lblQty1.setVisible(true);
        this.lblQty2.setVisible(true);
        
        this.lblPIcon1.setVisible(true);
        this.lblPIcon2.setVisible(true);
        
    }
    
     // MATCH INITIALIZATION METHODS //
   
    
    // GAME METHODS //
    
    private void deal(){
        this.startTime = getTime();
        this.startDate = getDate();
        //System.out.println("Deck size: " + this.deck.size());
        
        while(!this.deck.isEmpty()){
            this.player1.addToDrawStack(this.deck.pop()); 
            this.player2.addToDrawStack((this.deck.pop()));
        }
        //dump();
        updateCardCounters();
        showUIElements();
        //System.out.println("Done dealing");
        player1.setCanPlay(true);
        player2.setCanPlay(true);
        this.active1 = true;
        this.active2 = true;
        turn = 1;
    }
    
    private void play(Player player){
        turn = -1;
        animEmptyDrawSt(player);
        //victory(player); //****
        
        if(warMode){
            this.lblBoardDummy1.setIcon(cardBack);
            this.lblBoardDummy2.setIcon(cardBack);
            updateBoardVisibility(player);
            
            if(player==player1)turnWarA();
            else turnWarB();
        }
        else{
            player.setCanPlay(false);
            this.animReplenish(player);
            Card card = player.draw();
            this.updateCardCounters();
            BOARD.add(new BoardNode(card,player));
            this.animPlayCard(player, card);
            Player winner = null;
            
            if(BOARD.size()==2){
                if(BOARD.get(0).getCard().getRank()>BOARD.get(1).getCard().getRank()){
                    winner = BOARD.get(0).getPlayer();
                }
                else if(BOARD.get(0).getCard().getRank()<BOARD.get(1).getCard().getRank()){
                    winner = BOARD.get(1).getPlayer();
                }
                else{
                    initWar();
                }
                
                if(winner!=null){
                    winCards(winner,false);
                    player1.setCanPlay(true);
                    player2.setCanPlay(true);
                    endTurn(winner);
                }
            } 
        }
        turn=1;
    }
    
    protected void actionPlayer1(){
        if(!canWin){
            if(turn==1 && player1.canPlay()){
                this.active1 = false;
                this.play(player1);
            }
        }
        else{
            this.animWinCard(prevWinner);
            this.canWin = false;
            this.lblTake1.setVisible(false);
            this.lblTake2.setVisible(false);
        }
        
    }
    
    protected void actionPlayer2(){
        if(!canWin){
            if(turn==1 && player2.canPlay()){
                this.active2 = false;
                this.play(player2);
            }    
        }
        else{
            this.animWinCard(prevWinner);
            this.canWin = false;
            this.lblTake1.setVisible(false);
            this.lblTake2.setVisible(false);
        }
    }
    
    private void winCards(Player winner,boolean war){
        if(!war) Collections.sort(BOARD, new BoardNode());
        this.animTakeMsg(winner);
        winner.addWonExchange();
        this.canWin = true;
        this.prevWinner = winner;
        
        for (int i = 0; i < BOARD.size(); i++) {
            winner.addToDiscardStack(BOARD.get(i).getCard());
        }
        /*if(winner==player1){ //FOR TESTING PURPOSES
            results+="h";
        }
        else{
            results+="c";
        }*/
        this.BOARD=new ArrayList<>();
        //System.out.println(winner.getName() + " won the exchange!");
        //System.out.println("----------------------------------");
    }
    
    private void endTurn(Player winner){
        if(hasLost(pickLoser(winner))){
            turn=-1;
            victory(winner);
        }     
    }
    
    private void initWar(){
        this.rem1 = 4;
        this.rem2 = 4;
        this.warMode = true;
        this.warMult++;
        this.player1.setCanPlay(true);
        this.player2.setCanPlay(true);
        this.initWarUI();
        //System.out.println("WAR!!");
        
        if(this.BOARD.size()>0){
            miniStackA.push(new BoardNode(BOARD.get(0).getCard(),BOARD.get(0).getPlayer())); 
            miniStackB.push(new BoardNode(BOARD.get(1).getCard(),BOARD.get(1).getPlayer()));
            this.BOARD = new ArrayList<>();
        }
    }
    
    private void turnWarA() throws EmptyStackException{
        try{
            if(miniStackA.size()<4*warMult+1){
                animReplenish(player1);
                Card card = player1.draw();
                this.lblRemWarCards1.setText(String.valueOf(--rem1));
                
                if(rem1==0){
                    this.lblRemWarCards1.setVisible(false);
                    this.lblWarMsg1.setVisible(false);
                }
                
                this.updateCardCounters();
                miniStackA.push(new BoardNode(card,player1));
                this.animPlayCard(player1 , card);
            
                if(miniStackA.size()==4*warMult+1){
                    player1.setCanPlay(false);
                    finishWar('A');
                }
            }   
        } catch(EmptyStackException e){
            this.changeBackground();
            victory(player2);
        }
    }
    
    private void turnWarB() throws EmptyStackException{ 
        try{
            if(miniStackB.size()<4*warMult+1){
                animReplenish(player2);
                Card card = player2.draw();
                this.lblRemWarCards2.setText(String.valueOf(--rem2));
                
                if(rem2 == 0) {
                    this.lblRemWarCards2.setVisible(false);
                    this.lblWarMsg2.setVisible(false);
                }
                
                this.updateCardCounters();
                miniStackB.push(new BoardNode(card,player2));
                this.animPlayCard(player2 , card);
            
                if(miniStackB.size()==4*warMult+1){
                    player2.setCanPlay(false);
                    finishWar('B');
                }
            }
            
        } catch(EmptyStackException e){
            this.changeBackground();
            victory(player1);
        }
    }
    
    private void finishWar(char notifier){
        boolean proceed = false;
        
        if(notifier=='A') proceed = miniStackB.size()==4*warMult+1;
        if(notifier=='B') proceed = miniStackA.size()==4*warMult+1;
        
        if(proceed) {
            
            if(miniStackA.peek().getCard().getRank()==miniStackB.peek().getCard().getRank()){
                initWar();
            }
            else{
                warMult=0;
                Stack<BoardNode> winnerStack = miniStackA.peek().getCard().getRank()>miniStackB.peek().getCard().getRank()? miniStackA : miniStackB;
                Stack<BoardNode> loserStack = pickLoserStack(winnerStack);
                BoardNode winnerNode = winnerStack.peek();
                loserStack.addAll(winnerStack);
                Player winner = winnerNode.getPlayer();
                this.BOARD = new ArrayList<>(loserStack);
                this.miniStackA = new Stack<>();
                this.miniStackB = new Stack<>();
                this.warCounter++;
                winCards(winner,true);
                winner.addWonWars();
                this.warMode = false;
                player1.setCanPlay(true);
                player2.setCanPlay(true);
                this.changeBackground();
                endTurn(winner);
            }
        }
    }
    
    private void victory(Player player){
        this.finishTime = getTime();
        this.finishDate = getDate();
        player1.setCanPlay(false);
        player2.setCanPlay(false);
        this.animVictory(player, pickLoser(player));
        genRecord(player);
        //System.out.println(player.getName() + " WINS!");
        
        /*for (int i = 0; i < results.length(); i++) { FOR TESTING PURPOSES
            System.out.println(i+1+": "+results.charAt(i));
        }*/
        /**
        this.gui.musicStop();
        this.gui.setMusicStatus(false);
        this.gui.getpMenu().changeButtonIconMute();
        this.gui.getpMatchSetup().changeButtonIconMute();
        this.gui.getpWar().changeButtonIconMute();
        **/
    }
    
    // GAME METHODS //
    
    
    // ANIMATION METHODS //
    
    private void animPlayCard(Player player, Card card){
        if(player == player1){
            lblDrawCard1.setIcon(cardBack); 
            current1 = card;
            x1 = 574; y1 = 490;
            this.animPlayCard1();
        }
        else{
            lblDrawCard2.setIcon(cardBack);
            current2 = card; 
            x2 = 574; y2 = 20;
            this.animPlayCard2();
        }
    }
    
    private void animPlayCard1(){
        turn = -1;
        tm = new Timer(1,new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                lblDrawCard1.setLocation(x1++, y1-=2);
                if(y1==256) {
                    tm.stop();
                    turn = 1;
                    if(isCpu())btnDraw1.setEnabled(true); 
                    active1 = true;
                    lblDrawCard1.setIcon(current1.getFace());
                }
            }
        }); 
        tm.start();
    }
    
    private void animPlayCard2(){
        turn = -1;
        tm2 = new Timer(1,new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                lblDrawCard2.setLocation(x2--, y2+=2);
                if(y2==256) {
                    tm2.stop();
                    turn = 1;
                    //btnDraw2.setEnabled(true);
                    active2 = true;
                    lblDrawCard2.setIcon(current2.getFace());
                }
            }
        }); 
        tm2.start();
    }
      
    private void animWinCard(Player player){
        if (player == player1){
            this.animWinCard1();
        }
        else{
            this.animWinCard2();
        }
    }
    
    private void animWinCard1(){
        turn = -1;
        tm3 = new Timer(1, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lblDrawCard1.setLocation(x1++, y1+=2);
                lblDrawCard2.setLocation(x2+=3,y2+=2);
                if(y1 == 490){
                    tm3.stop();
                    turn = 1;
                    lblDrawCard1.setIcon(cardBack); //NOT NECESARY
                    lblDiscardDummy1.setIcon(current1.getFace());
                    lblDiscardDummy1.setVisible(true);
                    //btnDraw1.setEnabled(true); //maybe not necessary
                    //active1=true;
                    lblBoardDummy1.setVisible(false);
                    lblBoardDummy2.setVisible(false);
                    updateCardCounters();
                }
            }
        });
        tm3.start();
    }
    
    private void animWinCard2(){
        turn = -1;
        tm4 = new Timer(1, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                lblDrawCard2.setLocation(x2--,y2-=2);
                lblDrawCard1.setLocation(x1-=3,y1-=2);
                if(y2 == 20){
                    tm4.stop();
                    turn = 1;
                    lblDrawCard2.setIcon(cardBack); //CHANGE
                    lblDiscardDummy2.setIcon(current2.getFace());
                    lblDiscardDummy2.setVisible(true);
                    
                    lblBoardDummy1.setVisible(false);
                    lblBoardDummy2.setVisible(false);
                    updateCardCounters();
                }
            }
        });
        tm4.start();
    }
    
    private void animReplenish(Player player){
        if(player.getDrawStack().isEmpty()){
            JLabel lbldis = player==player1?lblDiscardDummy1 : lblDiscardDummy2;
            lbldis.setVisible(false);
        }
    }
    
    private void animTakeMsg(Player player){
        JLabel lbl = player==player1 ? lblTake1 : lblTake2;
        lbl.setVisible(true);
    }
    
    private void animEmptyDrawSt(Player player){
        JLabel lbldrw = player==player1?lblDrawDummy1 : lblDrawDummy2;
        if(player.getDrawStack().size()==1){
            lbldrw.setVisible(false);
        }
        else{
            lbldrw.setVisible(true);
        }
    }
    
    private void animVictory(Player winner, Player loser){
        this.hideUIElements();
        this.lblBigWinnerTag.setText(winner.getName());
        this.lblBigLoserTag.setText(loser.getName());
        this.lblBigWinnerTag.setVisible(true);
        this.lblWins.setVisible(true);
        this.lblBigLoserTag.setVisible(true);
        this.lblOutOfCards.setVisible(true);
        this.btnPlayAgain.setVisible(true);
        this.btnRtrnMainMenu.setVisible(true);
        this.btnMM.setVisible(false);
    }
    
    // ANIMATION METHODS //
    
    
    // ASSIST METHODS //
     private void dump(){
        player1.addToDrawStack(new Card(8));
        player1.addToDrawStack(new Card(14));
        player1.addToDrawStack(new Card("spades",12,new ImageIcon("QS.png")));
        player1.addToDrawStack(new Card("hearts",6,new ImageIcon("6H.png")));
        player1.addToDrawStack(new Card("clubs",2,new ImageIcon("2C.png")));
        player1.addToDrawStack(new Card("clubs",3,new ImageIcon("3C.png")));
        player1.addToDrawStack(new Card("hearts",3,new ImageIcon("3H.png")));
        player1.addToDrawStack(new Card("diamonds", 10, new ImageIcon("10D.png")));
        player2.addToDrawStack(new Card(11));
        player2.addToDrawStack(new Card(10));
        player2.addToDrawStack(new Card("clubs",8,new ImageIcon("8C.png")));
        player2.addToDrawStack(new Card("diamonds",5,new ImageIcon("5D.png")));
        player2.addToDrawStack(new Card("diamonds",2,new ImageIcon("2D.png")));
        player2.addToDrawStack(new Card("diamonds",3,new ImageIcon("3D.png")));
        player2.addToDrawStack(new Card("spades",3,new ImageIcon("3S.png")));
        player2.addToDrawStack(new Card("clubs",7,new ImageIcon("7C.png")));
        
        
        /*player1.addToDrawStack(new Card(11));
        player1.addToDrawStack(new Card(12));
        player1.addToDrawStack(new Card(7));
        player1.addToDrawStack(new Card(6));
        player1.addToDrawStack(new Card(6));
        player1.addToDrawStack(new Card(5));
        player1.addToDrawStack(new Card(2));
        player1.addToDrawStack(new Card(9));
        player1.addToDrawStack(new Card(14));
        player1.addToDrawStack(new Card(3));
        player1.addToDrawStack(new Card(7));
        player1.addToDrawStack(new Card(11));
        player1.addToDrawStack(new Card(4));
        
        player2.addToDrawStack(new Card(13));
        player2.addToDrawStack(new Card(4));
        player2.addToDrawStack(new Card(2));
        player2.addToDrawStack(new Card(5));
        player2.addToDrawStack(new Card(10));
        player2.addToDrawStack(new Card(8));
        player2.addToDrawStack(new Card(13));
        player2.addToDrawStack(new Card(9));
        player2.addToDrawStack(new Card(10));
        player2.addToDrawStack(new Card(3));
        player2.addToDrawStack(new Card(12));
        player2.addToDrawStack(new Card(14));
        player2.addToDrawStack(new Card(8));*/
        
        
        //check normal winning conditions
        //player1.addToDrawStack(new Card(9));
        //player2.addToDrawStack(new Card(10));
        //WAR CHECKER
        /*this.player1.addToDrawStack(new Card(11));
        this.player1.addToDrawStack(new Card(10));
        this.player1.addToDrawStack(new Card(2));
        this.player1.addToDrawStack(new Card(2));
        this.player1.addToDrawStack(new Card(2));
        this.player1.addToDrawStack(new Card(3));
        this.player1.addToDrawStack(new Card(6));
        this.player1.addToDrawStack(new Card(3));
        this.player1.addToDrawStack(new Card(4));
        this.player1.addToDrawStack(new Card(2));
        
        this.player2.addToDrawStack(new Card(11));
        this.player2.addToDrawStack(new Card(10));
        this.player2.addToDrawStack(new Card(2));
        this.player2.addToDrawStack(new Card(2));
        this.player2.addToDrawStack(new Card(2));
        this.player2.addToDrawStack(new Card(3));
        this.player2.addToDrawStack(new Card(2));
        this.player2.addToDrawStack(new Card(9));
        this.player2.addToDrawStack(new Card(7));
        this.player2.addToDrawStack(new Card(2));*/
        
    }
     
     private void updateCardCounters(){
        this.lblQty1.setText(String.valueOf(player1.manyCards()));
        this.lblQty2.setText(String.valueOf(player2.manyCards()));
    }
     
     private void updateBoardVisibility(Player player){
        if(player == player1 && miniStackA.size()==4*warMult-3){
            this.lblBoardDummy1.setVisible(true);
        }
        if(player == player2 && miniStackB.size()==4*warMult-3){
            this.lblBoardDummy2.setVisible(true);
        }
        if(player == player1 && miniStackA.size()==4*warMult){
            this.lblBoardDummy1.setVisible(false);
        }
        if(player == player2 && miniStackB.size()==4*warMult){
            this.lblBoardDummy2.setVisible(false);
        }
    }
     
     private void initWarUI(){
        this.lblWarMsg1.setVisible(true);
        this.lblWarMsg2.setVisible(true);
        this.lblRemWarCards1.setText(String.valueOf(rem1));
        this.lblRemWarCards2.setText(String.valueOf(rem2));
        this.lblRemWarCards1.setVisible(true);
        this.lblRemWarCards2.setVisible(true);
        this.changeBackground();
        
    }
    
     private boolean hasLost(Player player){
        if(player.getDrawStack().isEmpty()){
            if(!player.getDiscardStack().isEmpty()){
                animReplenish(player);
                animEmptyDrawSt(player);
                player.replenishDrawStack();
                return false;
            }
            return true;
        }
        return false;
    }
     
     private Player pickLoser(Player winner){
        if(winner==player1){
            return player2;
        }
        return player1;
    }
     
     private Stack<BoardNode> pickLoserStack(Stack<BoardNode> winner){
        if(winner==miniStackA){
            return miniStackB;
        }
        return miniStackA;
    }
     
     private void genRecord(Player winner){
        Player loser = pickLoser(winner);
        MatchRecord record = new MatchRecord(this, winner, loser);
        System.out.println(record);
    }
     
    private String getTime(){
        Date date = new Date();
        String strDateFormat = "hh:mm a";
        DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
        return dateFormat.format(date);
    }
    
    private String getDate(){
        Date date = new Date();
        String strDateFormat = "MM/dd/yyyy";
        DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
        return dateFormat.format(date);
    }
    
    private void changeBackground(){
        this.background = background == warBG ? regBG : warBG; 
        repaint();
    }
     
    // ASSIST METHODS //
     
    
    // MUSIC METHODS //
    
    public void changeButtonIconMute(){
        this.musicButton.setIcon(new ImageIcon("mute.png"));     
    }
    
    public void changeButtonIconVolume(){
        this.musicButton.setIcon(new ImageIcon("volume.png"));       
    }
    
    // MUSIC METHODS //
    
    
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnDeal = new javax.swing.JButton();
        btnScore = new javax.swing.JButton();
        btnDraw2 = new javax.swing.JButton();
        lblDiscardDummy1 = new javax.swing.JLabel();
        lblDiscardDummy2 = new javax.swing.JLabel();
        lblPIcon1 = new javax.swing.JLabel();
        lblBoardDummy1 = new javax.swing.JLabel();
        lblBoardDummy2 = new javax.swing.JLabel();
        lblDrawCard2 = new javax.swing.JLabel();
        lblDrawCard1 = new javax.swing.JLabel();
        lblDrawDummy1 = new javax.swing.JLabel();
        lblDrawDummy2 = new javax.swing.JLabel();
        musicButton = new javax.swing.JButton();
        lblNameTag1 = new javax.swing.JLabel();
        lblManyC1 = new javax.swing.JLabel();
        lblQty1 = new javax.swing.JLabel();
        lblNameTag2 = new javax.swing.JLabel();
        lblManyC2 = new javax.swing.JLabel();
        lblQty2 = new javax.swing.JLabel();
        lblPIcon2 = new javax.swing.JLabel();
        lblWarMsg1 = new javax.swing.JLabel();
        lblWarMsg2 = new javax.swing.JLabel();
        lblRemWarCards1 = new javax.swing.JLabel();
        lblRemWarCards2 = new javax.swing.JLabel();
        lblRepMsg1 = new javax.swing.JLabel();
        lblRepMsg2 = new javax.swing.JLabel();
        lblTake1 = new javax.swing.JLabel();
        lblTake2 = new javax.swing.JLabel();
        btnDraw1 = new javax.swing.JButton();
        lblBigWinnerTag = new javax.swing.JLabel();
        lblWins = new javax.swing.JLabel();
        lblBigLoserTag = new javax.swing.JLabel();
        lblOutOfCards = new javax.swing.JLabel();
        btnRtrnMainMenu = new javax.swing.JButton();
        btnPlayAgain = new javax.swing.JButton();
        btnKeep = new javax.swing.JButton();
        btnGotoSetup = new javax.swing.JButton();
        btnMM = new javax.swing.JButton();
        lblKey2 = new javax.swing.JLabel();
        lblKey1 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(1280, 720));
        setLayout(null);

        btnDeal.setText("DEAL");
        btnDeal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDealActionPerformed(evt);
            }
        });
        add(btnDeal);
        btnDeal.setBounds(545, 325, 190, 70);

        btnScore.setText("Score");
        btnScore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnScoreActionPerformed(evt);
            }
        });
        add(btnScore);
        btnScore.setBounds(1119, 410, 90, 23);

        btnDraw2.setText("PLAY2");
        btnDraw2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDraw2ActionPerformed(evt);
            }
        });
        add(btnDraw2);
        btnDraw2.setBounds(1130, 620, 100, 23);

        lblDiscardDummy1.setText("DiscardDummy1");
        add(lblDiscardDummy1);
        lblDiscardDummy1.setBounds(807, 490, 128, 178);

        lblDiscardDummy2.setText("DiscardDummy2");
        add(lblDiscardDummy2);
        lblDiscardDummy2.setBounds(339, 20, 128, 178);

        lblPIcon1.setText("saddle");
        add(lblPIcon1);
        lblPIcon1.setBounds(20, 490, 128, 178);

        lblBoardDummy1.setText("BoardDummy1");
        lblBoardDummy1.setPreferredSize(new java.awt.Dimension(128, 178));
        add(lblBoardDummy1);
        lblBoardDummy1.setBounds(690, 256, 128, 178);

        lblBoardDummy2.setText("BoardDummy2");
        add(lblBoardDummy2);
        lblBoardDummy2.setBounds(457, 256, 128, 178);

        lblDrawCard2.setText("DrawCard2");
        add(lblDrawCard2);
        lblDrawCard2.setBounds(574, 20, 128, 178);

        lblDrawCard1.setText("DrawCard1");
        add(lblDrawCard1);
        lblDrawCard1.setBounds(574, 490, 128, 178);

        lblDrawDummy1.setText("DrawDummy1");
        add(lblDrawDummy1);
        lblDrawDummy1.setBounds(574, 490, 128, 178);

        lblDrawDummy2.setText("DrawDummy2");
        add(lblDrawDummy2);
        lblDrawDummy2.setBounds(574, 20, 128, 178);

        musicButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                musicButtonActionPerformed(evt);
            }
        });
        add(musicButton);
        musicButton.setBounds(1220, 637, 41, 40);

        lblNameTag1.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        lblNameTag1.setForeground(new java.awt.Color(255, 255, 255));
        lblNameTag1.setText("NameTag");
        add(lblNameTag1);
        lblNameTag1.setBounds(160, 600, 200, 27);

        lblManyC1.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        lblManyC1.setForeground(new java.awt.Color(255, 255, 255));
        lblManyC1.setText("Cards: x");
        add(lblManyC1);
        lblManyC1.setBounds(160, 640, 81, 27);

        lblQty1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblQty1.setForeground(new java.awt.Color(255, 255, 255));
        lblQty1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblQty1.setText("00");
        add(lblQty1);
        lblQty1.setBounds(240, 640, 60, 29);

        lblNameTag2.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        lblNameTag2.setForeground(new java.awt.Color(255, 255, 255));
        lblNameTag2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblNameTag2.setText("NameTag2");
        add(lblNameTag2);
        lblNameTag2.setBounds(940, 20, 160, 27);

        lblManyC2.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        lblManyC2.setForeground(new java.awt.Color(255, 255, 255));
        lblManyC2.setText("Cards: x");
        add(lblManyC2);
        lblManyC2.setBounds(990, 60, 81, 27);

        lblQty2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblQty2.setForeground(new java.awt.Color(255, 255, 255));
        lblQty2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblQty2.setText("00");
        add(lblQty2);
        lblQty2.setBounds(1070, 60, 40, 29);

        lblPIcon2.setText("saddle");
        add(lblPIcon2);
        lblPIcon2.setBounds(1126, 20, 128, 178);

        lblWarMsg1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblWarMsg1.setForeground(new java.awt.Color(255, 255, 255));
        lblWarMsg1.setText("You're on war! Keep playing cards:");
        add(lblWarMsg1);
        lblWarMsg1.setBounds(480, 450, 280, 22);

        lblWarMsg2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblWarMsg2.setForeground(new java.awt.Color(255, 255, 255));
        lblWarMsg2.setText("You're on war! Keep playing cards:");
        add(lblWarMsg2);
        lblWarMsg2.setBounds(480, 218, 280, 22);

        lblRemWarCards1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblRemWarCards1.setForeground(new java.awt.Color(255, 255, 255));
        lblRemWarCards1.setText("0");
        add(lblRemWarCards1);
        lblRemWarCards1.setBounds(760, 442, 30, 40);

        lblRemWarCards2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblRemWarCards2.setForeground(new java.awt.Color(255, 255, 255));
        lblRemWarCards2.setText("0");
        add(lblRemWarCards2);
        lblRemWarCards2.setBounds(760, 210, 30, 40);

        lblRepMsg1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblRepMsg1.setForeground(new java.awt.Color(255, 255, 255));
        lblRepMsg1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRepMsg1.setText("Play to replenish!");
        add(lblRepMsg1);
        lblRepMsg1.setBounds(574, 490, 128, 178);

        lblRepMsg2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblRepMsg2.setForeground(new java.awt.Color(255, 255, 255));
        lblRepMsg2.setText("Play to replenish!");
        add(lblRepMsg2);
        lblRepMsg2.setBounds(574, 20, 128, 178);

        lblTake1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTake1.setForeground(new java.awt.Color(255, 255, 255));
        lblTake1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTake1.setText("Take your cards!");
        add(lblTake1);
        lblTake1.setBounds(565, 450, 150, 22);

        lblTake2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTake2.setForeground(new java.awt.Color(255, 255, 255));
        lblTake2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTake2.setText("Take your cards!");
        add(lblTake2);
        lblTake2.setBounds(565, 218, 150, 20);

        btnDraw1.setBorderPainted(false);
        btnDraw1.setContentAreaFilled(false);
        btnDraw1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDraw1ActionPerformed(evt);
            }
        });
        add(btnDraw1);
        btnDraw1.setBounds(574, 490, 128, 178);

        lblBigWinnerTag.setFont(new java.awt.Font("Tahoma", 0, 70)); // NOI18N
        lblBigWinnerTag.setForeground(new java.awt.Color(255, 255, 255));
        lblBigWinnerTag.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBigWinnerTag.setText("bigWinnerTag");
        add(lblBigWinnerTag);
        lblBigWinnerTag.setBounds(140, 40, 1000, 130);

        lblWins.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        lblWins.setForeground(new java.awt.Color(255, 255, 255));
        lblWins.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblWins.setText("WINS!");
        add(lblWins);
        lblWins.setBounds(555, 160, 170, 90);

        lblBigLoserTag.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblBigLoserTag.setForeground(new java.awt.Color(255, 255, 255));
        lblBigLoserTag.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBigLoserTag.setText("bigLoserTag");
        add(lblBigLoserTag);
        lblBigLoserTag.setBounds(825, 300, 230, 40);

        lblOutOfCards.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblOutOfCards.setForeground(new java.awt.Color(255, 255, 255));
        lblOutOfCards.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblOutOfCards.setText("'s out of cards...");
        add(lblOutOfCards);
        lblOutOfCards.setBounds(1050, 300, 180, 40);

        btnRtrnMainMenu.setText("Return to Main Menu");
        btnRtrnMainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRtrnMainMenuActionPerformed(evt);
            }
        });
        add(btnRtrnMainMenu);
        btnRtrnMainMenu.setBounds(755, 450, 180, 60);

        btnPlayAgain.setText("Play Again");
        btnPlayAgain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlayAgainActionPerformed(evt);
            }
        });
        add(btnPlayAgain);
        btnPlayAgain.setBounds(345, 450, 180, 60);

        btnKeep.setText("Keep my settings");
        btnKeep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKeepActionPerformed(evt);
            }
        });
        add(btnKeep);
        btnKeep.setBounds(345, 530, 180, 23);

        btnGotoSetup.setText("Go to setup");
        btnGotoSetup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGotoSetupActionPerformed(evt);
            }
        });
        add(btnGotoSetup);
        btnGotoSetup.setBounds(345, 560, 180, 23);

        btnMM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMMActionPerformed(evt);
            }
        });
        add(btnMM);
        btnMM.setBounds(20, 20, 41, 40);

        lblKey2.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        lblKey2.setForeground(new java.awt.Color(255, 255, 255));
        lblKey2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKey2.setText("[L] to play");
        add(lblKey2);
        lblKey2.setBounds(995, 100, 110, 30);

        lblKey1.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        lblKey1.setForeground(new java.awt.Color(255, 255, 255));
        lblKey1.setText("[S] to play");
        add(lblKey1);
        lblKey1.setBounds(160, 560, 110, 30);
    }// </editor-fold>//GEN-END:initComponents

    private void btnDealActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDealActionPerformed
        deal();
    }//GEN-LAST:event_btnDealActionPerformed

    private void btnScoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnScoreActionPerformed
        
        System.out.print(player1.getName()+" : Draw : [");
        for (int i = 0; i < player1.getDrawStack().size(); i++) {
            System.out.print(player1.getDrawStack().get(i).getRank()+" , ");
        }
        System.out.print("] // Discard: [");
        for (int i = 0; i < player1.getDiscardStack().size(); i++) {
            System.out.print(player1.getDiscardStack().get(i).getRank()+" , ");
        }
        System.out.print("]");
        
        System.out.println("");
        
        System.out.print(player2.getName()+" : Draw : [");
        for (int i = 0; i < player2.getDrawStack().size(); i++) {
            System.out.print(player2.getDrawStack().get(i).getRank()+" , ");
        }
        System.out.print("] // Discard: [");
        for (int i = 0; i < player2.getDiscardStack().size(); i++) {
            System.out.print(player2.getDiscardStack().get(i).getRank()+" , ");
        }
        System.out.print("]");
        System.out.println("");
        
    }//GEN-LAST:event_btnScoreActionPerformed

    private void btnDraw1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDraw1ActionPerformed
        if(isCpu()){
            if(!canWin){
                if(turn==1 && player1.canPlay()){
                    btnDraw1.setEnabled(false);
                    play(player1);
                    if(turn==1 && player2.canPlay()){
                        play(player2);
                    }
                }
            }
            else{
                this.animWinCard(prevWinner);
                canWin = false;
                this.lblTake1.setVisible(false);
                this.lblTake2.setVisible(false);
            }
            
        }
    }//GEN-LAST:event_btnDraw1ActionPerformed

    private void btnDraw2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDraw2ActionPerformed
        /*if(!cpu){
            if(!canWin){
                if(turn==1 && player2.canPlay()){
                btnDraw2.setEnabled(false);
                play(player2);
                }
                
            }
            else{
                this.animWinCard(prevWinner);
                canWin = false;
                this.lblTake1.setVisible(false);
                this.lblTake2.setVisible(false);
            }
        }     
        */
    }//GEN-LAST:event_btnDraw2ActionPerformed

    private void musicButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_musicButtonActionPerformed
        if(this.gui.getMusicStatus()){
            this.gui.musicStop();
            this.gui.setMusicStatus(false);
            System.out.println(this.gui.getMusicStatus());
            this.changeButtonIconMute();
            this.setFocusable(true);
            this.requestFocusInWindow();
        }
        else{
            this.gui.musicPlay();
            this.gui.setMusicStatus(true);
            this.changeButtonIconVolume();
            this.setFocusable(true);
            this.requestFocusInWindow();
        }
    }//GEN-LAST:event_musicButtonActionPerformed

    private void btnRtrnMainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRtrnMainMenuActionPerformed
        this.gui.goToMenu();
       
    }//GEN-LAST:event_btnRtrnMainMenuActionPerformed

    private void btnPlayAgainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlayAgainActionPerformed
        
        this.btnKeep.setVisible(true);
        this.btnGotoSetup.setVisible(true);
        
    }//GEN-LAST:event_btnPlayAgainActionPerformed

    private void btnGotoSetupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGotoSetupActionPerformed
        this.gui.goToSetup(new GameManager(this.gui));
    }//GEN-LAST:event_btnGotoSetupActionPerformed

    private void btnKeepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKeepActionPerformed
        this.manager.resetVariables();
        if(this.gui.getMusicStatus()){
            this.gui.getpWar().changeButtonIconVolume();
            this.gui.musicPlay();
        }
        else{
            this.gui.getpWar().changeButtonIconMute();
            this.gui.musicStop();
        }
    }//GEN-LAST:event_btnKeepActionPerformed

    private void btnMMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMMActionPerformed
        
        String msg = "Exit to setup screen? Changes will not be saved.";
        int answer = JOptionPane.showConfirmDialog(this, msg);
        if(answer==JOptionPane.YES_OPTION){
            this.gui.goToSetup(new GameManager(this.gui));
        }
        else{
            this.setFocusable(true);
            this.requestFocusInWindow();
        }
    }//GEN-LAST:event_btnMMActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeal;
    private javax.swing.JButton btnDraw1;
    private javax.swing.JButton btnDraw2;
    private javax.swing.JButton btnGotoSetup;
    private javax.swing.JButton btnKeep;
    private javax.swing.JButton btnMM;
    private javax.swing.JButton btnPlayAgain;
    private javax.swing.JButton btnRtrnMainMenu;
    private javax.swing.JButton btnScore;
    private javax.swing.JLabel lblBigLoserTag;
    private javax.swing.JLabel lblBigWinnerTag;
    private javax.swing.JLabel lblBoardDummy1;
    private javax.swing.JLabel lblBoardDummy2;
    private javax.swing.JLabel lblDiscardDummy1;
    private javax.swing.JLabel lblDiscardDummy2;
    private javax.swing.JLabel lblDrawCard1;
    private javax.swing.JLabel lblDrawCard2;
    private javax.swing.JLabel lblDrawDummy1;
    private javax.swing.JLabel lblDrawDummy2;
    private javax.swing.JLabel lblKey1;
    private javax.swing.JLabel lblKey2;
    private javax.swing.JLabel lblManyC1;
    private javax.swing.JLabel lblManyC2;
    private javax.swing.JLabel lblNameTag1;
    private javax.swing.JLabel lblNameTag2;
    private javax.swing.JLabel lblOutOfCards;
    private javax.swing.JLabel lblPIcon1;
    private javax.swing.JLabel lblPIcon2;
    private javax.swing.JLabel lblQty1;
    private javax.swing.JLabel lblQty2;
    private javax.swing.JLabel lblRemWarCards1;
    private javax.swing.JLabel lblRemWarCards2;
    private javax.swing.JLabel lblRepMsg1;
    private javax.swing.JLabel lblRepMsg2;
    private javax.swing.JLabel lblTake1;
    private javax.swing.JLabel lblTake2;
    private javax.swing.JLabel lblWarMsg1;
    private javax.swing.JLabel lblWarMsg2;
    private javax.swing.JLabel lblWins;
    private javax.swing.JButton musicButton;
    // End of variables declaration//GEN-END:variables

    /**
     * @return the warCounter
     */
    public int getWarCounter() {
        return warCounter;
    }

    /**
     * @return the cpu
     */
    public boolean isCpu() {
        return cpu;
    }

    /**
     * @return the startTime
     */
    public String getStartTime() {
        return startTime;
    }

    /**
     * @return the finishTime
     */
    public String getFinishTime() {
        return finishTime;
    }

    /**
     * @return the startDate
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * @return the finishDate
     */
    public String getFinishDate() {
        return finishDate;
    }

    /**
     * @return the halfDeck
     */
    public boolean isHalfDeck() {
        return halfDeck;
    }
    
    public Player getPlayer2(){
        return this.player2;
    }
    
}
