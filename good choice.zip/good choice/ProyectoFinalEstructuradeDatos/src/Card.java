import javax.swing.ImageIcon;

public class Card {
    private String suit;
    private int rank;
    private ImageIcon face;
    
    public Card(String suit, int rank, ImageIcon face){
       this.suit = suit;
       this.rank = rank;
       this.face = face;
    }
    
    public Card(int rank){
        this.rank = rank;
    }
    
    @Override
    public String toString(){
        return this.rank + " of " + this.suit;
    }

    /**
     * @return the suit
     */
    public String getSuit() {
        return suit;
    }

    /**
     * @return the rank
     */
    public int getRank() {
        return rank;
    }

    /**
     * @return the face
     */
    public ImageIcon getFace() {
        return face;
    }

}
