/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




/**
 *
 * @author Wislo
 */
public class MatchRecord {
    
    private int warCounter, wonWarsW, wonWarsL, drawnCardsW, drawnCardsL,
                wonExchangeW, wonExchangeL;
    private Player winner, loser;
    private String winnerName, loserName, gameType, cpu, startTime, 
            finishTime, startDate, finishDate;
    
    public MatchRecord(TheWar match, Player winner, Player loser) {
        this.winner = winner;
        this.loser = loser;
        this.winnerName = winner.getName();
        this.loserName = loser.getName();
        this.warCounter = match.getWarCounter();
        this.cpu = match.isCpu()? " (CPU) ":"";
        this.gameType = match.isHalfDeck() ? "Half-Deck":"Full-Deck";
        this.startTime = match.getStartTime();
        this.finishTime = match.getFinishTime();
        this.startDate = match.getStartDate();
        this.finishDate = match.getFinishDate();
        this.wonExchangeW = winner.getWonExchange();
        this.wonExchangeL = loser.getWonExchange();
        this.wonWarsW = winner.getWonWars();
        this.wonWarsL = loser.getWonWars();
        this.addCpuTag(match);
    }
    
    private void addCpuTag(TheWar match){
        if(winner == match.getPlayer2()){
            winnerName+=cpu;
        }
        else{
            loserName+=cpu;
        }
    }
    
    @Override
    public String toString(){
        String fulldate = startDate.equals(finishDate) ? startDate : startDate + " - " + finishDate;
        return fulldate +" "+startTime+" - "+finishTime+"  Game Type: "+gameType+"\n"
                +"Congrats, " + winnerName + " Won exchanges: "+ wonExchangeW+ "  Won Wars: "+ wonWarsW + "\n"
                +"Played against: "+ loserName + " Won exchanges: "+ wonExchangeL+ "  Won Wars: "+ wonWarsL + "\n"
                +"Total wars in match: "+ warCounter;
    }
    
    
}
