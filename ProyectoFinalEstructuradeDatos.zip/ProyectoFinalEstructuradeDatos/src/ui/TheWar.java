/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import WarClass.Card;
import WarClass.GameManager;
import WarClass.Player;
import WarClass.WarFrame;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.Stack;


class BoardNode{
    private Card card;
    private Player player;
    
    public BoardNode(Card card, Player player){
        this.card = card;
        this.player = player;
    }
    
    public Card getCard(){
        return this.card;
    }
    
    public Player getPlayer(){
        return this.player;
    }
    
}

public class TheWar extends javax.swing.JPanel {
    private WarFrame gui;
    private GameManager manager;
    private Stack<Card> deck ;
    private Stack <BoardNode> miniStackA, miniStackB;
    private Player player1;
    private Player player2;
    private Player cPlayer;
    private ArrayList<BoardNode> BOARD; 
    private int turn;
    /**
     * Creates new form TheWar
     */
    public TheWar(WarFrame gui, GameManager manager) {
        initComponents();
        this.gui = gui;
        this.manager = manager;
        this.deck = this.manager.getDeck().getDeck();
        this.player1 = this.manager.getPlayer1();
        this.player2 = this.manager.getPlayer2();
        this.BOARD = new ArrayList<>();
        miniStackA = new Stack<>();
        miniStackB = new Stack<>();
        this.btnDraw1.setVisible(false);
        this.btnDraw2.setVisible(false);
        this.turn=-1;
    }
    
    private void deal(){
        while(!this.deck.isEmpty()){
            this.player1.addToDrawStack(this.deck.pop()); //fix semantics
            this.player2.addToDrawStack((this.deck.pop()));
        }
        System.out.println("Done dealing");
        this.btnDeal.setVisible(false);
        this.btnDraw1.setVisible(true);
        this.btnDraw2.setVisible(true);
        //checar booleano de cpu y booleano de random turn
        System.out.println("Player 1 turn:"); 
        turn = 1;
        cPlayer = player1;
    }
    
    private void winCards(Player winner){
        for (int i = 0; i < BOARD.size(); i++) {
            winner.addToDiscardStack(BOARD.get(i).getCard());
        }
        String win = winner==player1?"player1":"player2";
        System.out.println(win + " won the exchange!");
        this.BOARD=new ArrayList<>();
        System.out.println("Board has been reset");
    }
    
    
    private void turn(){
        BOARD.add(new BoardNode(cPlayer.draw(),cPlayer));
        if(BOARD.size()==2){
            if(BOARD.get(0).getCard().getRank()>BOARD.get(1).getCard().getRank()){
                //AQUI
                Player winner = BOARD.get(0).getPlayer();
                
                winCards(BOARD.get(0).getPlayer());
            }
            else if(BOARD.get(0).getCard().getRank()<BOARD.get(1).getCard().getRank()){
                //AQUI
                winCards(BOARD.get(1).getPlayer());
            }
            else{
                turn=-1;
                System.out.println("WAR!");
                initWar();
            }
        }
        // verificar el estado de tus cartas
        changeTurn();
    }
    
    private void changeTurn(){ //aqui se puede cambiar el atributo de current player
        if(this.turn==2){
            System.out.println("Its player 1's turn");
            System.out.println("------------------------");
            cPlayer=player1;
            this.turn=1;
        }
        else if(this.turn == 1){
            System.out.println("Its player 2's turn");
            System.out.println("------------------------");
            cPlayer=player2;
            this.turn =2;
        }
    }
    
    private void initWar(){
        if(this.BOARD.size()>0){
            miniStackA.push(new BoardNode(BOARD.get(0).getCard(),BOARD.get(0).getPlayer()));
            miniStackB.push(new BoardNode(BOARD.get(1).getCard(),BOARD.get(1).getPlayer()));
        }
        turn = 0;
    
    }
    
    private void victory(Player player){
        System.out.println(player.getName() + " WINS!");
        
    }
    
    private void finishWar(char notifier){
        boolean proceed = false;
        if(notifier=='A') proceed = miniStackB.size()==5;
        if(notifier=='B') proceed = miniStackA.size()==5;
        
        if(proceed) {
            if(miniStackA.peek().getCard().getRank()==miniStackB.peek().getCard().getRank()){
                initWar();
            }
            else{
                BoardNode winner = miniStackA.peek().getCard().getRank()>miniStackB.peek().getCard().getRank()? miniStackA.peek() : miniStackB.peek();
                miniStackA.addAll(miniStackB);
                this.BOARD = new ArrayList<>(miniStackA);
                this.miniStackA = new Stack<>();
                this.miniStackB = new Stack<>();
                winCards(winner.getPlayer());
                
            }
        }
//cambiar el turn y darle las cartas al ganador
        
        
        
    }
    
    
    //TODOS LOS TURNOS THROW EMPTYSTACKEXCEPTION
    //en cada turno se debe checar al final el estado de tus cartas (tal vez eso quite la necesidad de cachar exceptions)
    private void turnWarA() throws EmptyStackException{ //trabaja con el stackA
        try{
            if(miniStackA.size()<5){
            miniStackA.push(new BoardNode(player1.draw(),player1));
            
                if(miniStackA.size()==5){
                    finishWar('A');
                }
        }   
        } catch(EmptyStackException e){
            System.out.println("PLAYER 2 WINS");
        }
        
    }
    
    private void turnWarB(){ //trabaja con el StackB
        try{
            if(miniStackB.size()<5){
            miniStackB.push(new BoardNode(player2.draw(),player2));
            
                if(miniStackB.size()==5){
                    finishWar('B');
                }
            }
            
        } catch(EmptyStackException e){
            System.out.println("PLAYER 1 WINS");
        }
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnDeal = new javax.swing.JButton();
        btnDraw1 = new javax.swing.JButton();
        btnDraw2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(800, 600));

        jLabel1.setText("saddle");

        btnDeal.setText("DEAL");
        btnDeal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDealActionPerformed(evt);
            }
        });

        btnDraw1.setText("Player1");
        btnDraw1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDraw1ActionPerformed(evt);
            }
        });

        btnDraw2.setText("Player2");
        btnDraw2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDraw2ActionPerformed(evt);
            }
        });

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(330, 330, 330)
                        .addComponent(btnDeal))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(128, 128, 128)
                        .addComponent(btnDraw1)
                        .addGap(261, 261, 261)
                        .addComponent(btnDraw2)))
                .addContainerGap(273, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(148, 148, 148)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(82, 82, 82))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(136, 136, 136)
                        .addComponent(jButton1)))
                .addGap(69, 69, 69)
                .addComponent(btnDeal)
                .addGap(107, 107, 107)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDraw1)
                    .addComponent(btnDraw2))
                .addContainerGap(219, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnDealActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDealActionPerformed
        deal();
    }//GEN-LAST:event_btnDealActionPerformed

    private void btnDraw1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDraw1ActionPerformed
        if(turn==1){
            this.btnDraw1.setVisible(false); //el flip es demasiado rapido
            turn();
            this.btnDraw1.setVisible(true);
            
        }
        else if(turn==0){
            turnWarA();
        }
    }//GEN-LAST:event_btnDraw1ActionPerformed

    private void btnDraw2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDraw2ActionPerformed
        if(turn==2){
            this.btnDraw2.setVisible(false);
            turn();
            this.btnDraw2.setVisible(true);
        }
        else if(turn==0){
            turnWarB();
        }
    }//GEN-LAST:event_btnDraw2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        System.out.print("Player 1: Draw : [");
        for (int i = 0; i < player1.getDrawStack().size(); i++) {
            System.out.print(player1.getDrawStack().get(i).getRank()+" , ");
        }
        System.out.print("] // Discard: [");
        for (int i = 0; i < player1.getDiscardStack().size(); i++) {
            System.out.print(player1.getDiscardStack().get(i).getRank()+" , ");
        }
        System.out.print("]");
        
        System.out.println("");
        
        System.out.print("Player 2: Draw : [");
        for (int i = 0; i < player2.getDrawStack().size(); i++) {
            System.out.print(player2.getDrawStack().get(i).getRank()+" , ");
        }
        System.out.print("] // Discard: [");
        for (int i = 0; i < player2.getDiscardStack().size(); i++) {
            System.out.print(player2.getDiscardStack().get(i).getRank()+" , ");
        }
        System.out.print("]");
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeal;
    private javax.swing.JButton btnDraw1;
    private javax.swing.JButton btnDraw2;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
