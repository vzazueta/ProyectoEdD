/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinalestructuradedatos;

import java.util.Stack;
import javax.swing.JFrame;

public class Player extends JFrame{
    //private String name;
    private Stack<Card> discardStack;
    private Stack<Card> drawStack;
    
    public Player(Deck deck){
        
        this.discardStack = new Stack<>();
        this.drawStack = new Stack<>();
    }
    
    public void discard(Card c){
        
    }
    
    public boolean addToDrawStack(){
        return true;
    }
    
    public boolean hasCards(){
        return true;
    }
    
    
    public String toString(){
        return "";
    }
    
    private void replenishDrawStack(){
        
    }
}
