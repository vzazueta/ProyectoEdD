
package proyectofinalestructuradedatos;

import java.util.Stack;

public class WarManager {
    private Deck deck;
    private Stack<Card> player1;
    private Stack<Card> player2;
}
