
package proyectofinalestructuradedatos;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Stack;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class Deck extends JFrame {
    private Stack<Card> deck;
    
    public Deck(String s){
        System.out.println(s);
    }
    
    public Deck() throws IOException{
        this.deck = new Stack<>();
        
        try {
               
        this.deck.add(
                new Card(
                        ImageIO.read(
                                new File(
                                        "cards_png_zip/PNG/2C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/2D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/2H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/2S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/3C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/3D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/3H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/3S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/4C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/4D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/4H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/4S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/5C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/5D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/5H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/5S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/6C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/6D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/6H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/6S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/7C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/7D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/7H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/7S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/8C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/8D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/8H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/8S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/9C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/9D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/9H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/9S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/10C.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/10D.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/10H.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/10S.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/AC.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/AD.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/AH.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/AS.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/JC.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/JD.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/JH.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/JS.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/QC.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/QD.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/QH.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/QS.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/KC.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/KD.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/KH.png"))));
        this.deck.add(new Card(ImageIO.read(new File("cards_png_zip/PNG/KS.png"))));
        
        } catch(IOException e){
            throw new IOException("Este path no es correcto");
        }
        
        this.shuffle();
    }
    
    
    public void shuffle(){
      Collections.shuffle(getDeck());
    }
    
    public Card draw(){
        return getDeck().pop();
    }
    
    private void swapElements(int a, int b){
        
    }

    public Stack<Card> getDeck() {
        return deck;
    }
    
    public Card getCard(){
        return this.deck.pop();
    }
}