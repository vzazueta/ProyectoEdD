
package proyectofinalestructuradedatos;

import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Card extends JFrame{
    //private Image card;
    //private BufferedImage bufim;
    private ImageIcon card;
    
    public Card(BufferedImage i){
       this.card.setImage(i);
    }
    
    public Image getFace() {
        return this.card.getImage();
    }

    public void setFace(Image image) {
        this.card.setImage(image);
    }
    
/*
    public int getFace() {
        return face;
    }

    public void setFace(int face) {
        this.face = face;
    }

    public String getSuit() {
        return suit;
    }

    public void setSuit(String suit) {
        this.suit = suit;
    }
    
    public String toString(){
        return this.face+", "+this.suit;
    }
*/

}
