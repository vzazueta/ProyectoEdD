
package proyectofinalestructuradedatos;

import java.io.IOException;
import javax.swing.JFrame;

public class ProyectoFinalEstructuradeDatos {

    public static void main(String[] args){ //throws IOException{
        
        String s = "No mames we ";
        
        System.out.println(s);
        //Deck deck = new Deck("ola k ase");
        //WarFrame gui = new WarFrame();
    }
    
}
