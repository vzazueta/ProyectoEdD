/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WarClass;

import javax.swing.ImageIcon;

/**
 *
 * @author Wislo
 */
public class GameManager {
    private WarFrame gui;
    private Player player1 , player2;
    private boolean cpu , halfDeck;
    private Deck deck;
    private ImageIcon board = new ImageIcon("board\\basic_green.png");
    
    
    public GameManager(WarFrame gui){
        this.gui = gui;
        this.player1 = new Player("Player 1");
        this.player2 = new Player("Player 2");
        this.cpu=false;
        this.halfDeck = false;
    }
    
    public void setHalfDeck(boolean halfDeck){
        this.halfDeck = halfDeck;
    }
    
    public ImageIcon getBoard(){
        return this.board;
    }
    
    public Player getPlayer1(){
        return this.player1;
    }
    
    public Player getPlayer2(){
        return this.player2;
    }
    
    public void setCPU(boolean cpu){
        this.cpu = cpu;
    }
    
    public Deck getDeck(){
        return this.deck;
    }
    
    public boolean getCPU(){
        return this.cpu;
    }
    
    
    
    public void run(){
        System.out.println("Game Starts");
        this.deck = new Deck(halfDeck);
        this.gui.goToWar(this);
        
        
        //mandar a llamar a la otra pantalla
        //deal cards
    }
    
    
    
}
