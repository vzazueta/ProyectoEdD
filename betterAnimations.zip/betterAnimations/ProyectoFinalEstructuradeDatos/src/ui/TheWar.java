/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import WarClass.*;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EmptyStackException;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.Timer;


class BoardNode implements Comparator<BoardNode>{
    private Card card;
    private Player player;
    
    public BoardNode(){
        
    }
    public BoardNode(Card card, Player player) throws EmptyStackException{
        if(card!=null){
            this.card = card;
            this.player = player;
        }
        else{
            throw new EmptyStackException();
        }
        
    }
    
    public Card getCard(){
        return this.card;
    }
    
    public Player getPlayer(){
        return this.player;
    }
    
    @Override
    public int compare(BoardNode a, BoardNode b) {
        return a.card.getRank()-b.card.getRank();
    }
    
}

public class TheWar extends javax.swing.JPanel{
    private WarFrame gui;
    private GameManager manager;
    private Stack<Card> deck;
    private Stack <BoardNode> miniStackA, miniStackB;
    private Player player1;
    private Player player2;
    private ArrayList<BoardNode> BOARD; 
    private int turn,warMult,warCounter,drawGuide,x1,y1,x2,y2;
    private boolean warMode,cpu;
    private String results;
    private ImageIcon background;
    private Timer tm , tm2;
    private Card current1, current2;
    
    /**
     * Creates new form TheWar
     */
    public TheWar(WarFrame gui, GameManager manager) {
        initComponents();
        this.background = manager.getBoard();
        this.gui = gui;
        this.manager = manager;
        this.deck = this.manager.getDeck().getDeck();
        this.player1 = this.manager.getPlayer1();
        this.player2 = this.manager.getPlayer2();
        this.BOARD = new ArrayList<>();
        this.miniStackA = new Stack<>();
        this.miniStackB = new Stack<>();
        this.cpu = manager.getCPU();
        hideUIElements();
        initGameVariables();
        
        //this.lblDiscardDummy1.setIcon(new ImageIcon("cards/2C.png"));
        //this.lblDiscardDummy2.setIcon(new ImageIcon("cards/2C.png"));
        this.lblTest3.setIcon(new ImageIcon("playerIcons/falcon.png"));
        this.lblTest5.setIcon(new ImageIcon("playerIcons/zss.png"));
        
    }
    
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(background.getImage(), 0, 0, this);
    }
    /*
    @Override
    public void actionPerformed(ActionEvent ae) {
        turn = -1;
        switch (drawGuide) {
            case 1:
                this.lblDrawCard1.setLocation(x1++, y1-=2);
                if(y1==256) {
                    tm.stop();
                    turn = 1;
                    this.lblDrawCard1.setIcon(current1.getFace());
                    drawGuide=0;
                }
                
                break;
            case 2:
                this.lblDrawCard2.setLocation(x2--, y2+=2);
                if(y2==256) {
                    tm.stop();
                    turn = 1;
                    this.lblDrawCard2.setIcon(current2.getFace());
                    drawGuide=0;
                }
                break;
            case 3:
                this.lblDrawCard1.setLocation(x1++, y1-=2);
                this.lblDrawCard2.setLocation(x2--, y2+=2);
                if(y1==256) {
                    tm.stop();
                    turn = 1;
                    this.lblDrawCard1.setIcon(current1.getFace());
                    this.lblDrawCard2.setIcon(current2.getFace());
                    drawGuide=0;
                }
                break;
            default:
                break;
        }
        
    }
    */
    private void hideUIElements(){
        this.btnDraw1.setVisible(false);
        this.btnDraw2.setVisible(false);
        this.lblDrawDummy1.setIcon(new ImageIcon("cards/purple.png"));
        this.lblDrawDummy2.setIcon(new ImageIcon("cards/purple.png"));
        this.lblDrawDummy1.setVisible(false);
        this.lblDrawDummy2.setVisible(false);
        this.lblWAR.setVisible(false);
    }
    
    private void initGameVariables(){
        this.turn=-1;
        this.warMult=0;
        this.warMode = false;
        this.results="";
        this.x1=574;
        this.y1 = 490;
        this.x2 = 574;
        this.y2 = 20;
        this.current1=null;
        this.current2=null;
        
    }
    
    private void genRecord(Player winner){
        Player loser = pickLoser(winner);
        MatchRecord record = new MatchRecord(winner,loser, warCounter, null);
    }
    
    private void animPlayCard(Player player){
        if(player == player1){
            current1 = player1.getDrawStack().peek();
            x1 = 574; y1 = 490;
            this.animPlayCard1();
        }
        else{
            current2 = player2.getDrawStack().peek(); //podria dar exception?
            x2 = 574; y2 = 20;
            this.animPlayCard2();
        }
    }
    
    private void animPlayCard1(){
        
        tm = new Timer(1,new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                lblDrawCard1.setLocation(x1++, y1-=2);
                if(y1==256) {
                    tm.stop();
                    turn = 1;
                    lblDrawCard1.setIcon(current1.getFace());
                    //drawGuide=0;
                
                }
            }
        }); 
        
        tm.start();
    }
    
    
    
    private void animPlayCard2(){
        
        tm2 = new Timer(1,new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                lblDrawCard2.setLocation(x2--, y2+=2);
                if(y2==256) {
                    tm2.stop();
                    turn = 1;
                    lblDrawCard2.setIcon(current2.getFace());
                    //drawGuide=0; //talvez no es necesario
                
                }
            }
        }); 
        
        tm2.start();
    }
                
    
    
    private void dump(){
        player1.addToDrawStack(new Card(12));
        player1.addToDrawStack(new Card(5));
        player1.addToDrawStack(new Card(4));
        
        player2.addToDrawStack(new Card(13));
        player2.addToDrawStack(new Card(8));
        player2.addToDrawStack(new Card(9));
        
        /*player1.addToDrawStack(new Card(11));
        player1.addToDrawStack(new Card(12));
        player1.addToDrawStack(new Card(7));
        player1.addToDrawStack(new Card(6));
        player1.addToDrawStack(new Card(6));
        player1.addToDrawStack(new Card(5));
        player1.addToDrawStack(new Card(2));
        player1.addToDrawStack(new Card(9));
        player1.addToDrawStack(new Card(14));
        player1.addToDrawStack(new Card(3));
        player1.addToDrawStack(new Card(7));
        player1.addToDrawStack(new Card(11));
        player1.addToDrawStack(new Card(4));
        
        player2.addToDrawStack(new Card(13));
        player2.addToDrawStack(new Card(4));
        player2.addToDrawStack(new Card(2));
        player2.addToDrawStack(new Card(5));
        player2.addToDrawStack(new Card(10));
        player2.addToDrawStack(new Card(8));
        player2.addToDrawStack(new Card(13));
        player2.addToDrawStack(new Card(9));
        player2.addToDrawStack(new Card(10));
        player2.addToDrawStack(new Card(3));
        player2.addToDrawStack(new Card(12));
        player2.addToDrawStack(new Card(14));
        player2.addToDrawStack(new Card(8));*/
        
        
        //check normal winning conditions
        //player1.addToDrawStack(new Card(9));
        //player2.addToDrawStack(new Card(10));
        //WAR CHECKER
        /*this.player1.addToDrawStack(new Card(11));
        this.player1.addToDrawStack(new Card(10));
        this.player1.addToDrawStack(new Card(2));
        this.player1.addToDrawStack(new Card(2));
        this.player1.addToDrawStack(new Card(2));
        this.player1.addToDrawStack(new Card(3));
        this.player1.addToDrawStack(new Card(6));
        this.player1.addToDrawStack(new Card(3));
        this.player1.addToDrawStack(new Card(4));
        this.player1.addToDrawStack(new Card(2));
        
        this.player2.addToDrawStack(new Card(11));
        this.player2.addToDrawStack(new Card(10));
        this.player2.addToDrawStack(new Card(2));
        this.player2.addToDrawStack(new Card(2));
        this.player2.addToDrawStack(new Card(2));
        this.player2.addToDrawStack(new Card(3));
        this.player2.addToDrawStack(new Card(2));
        this.player2.addToDrawStack(new Card(9));
        this.player2.addToDrawStack(new Card(7));
        this.player2.addToDrawStack(new Card(2));*/
        
    }
    
    private void prepUIElements(){
        this.btnDeal.setVisible(false);
        this.btnDraw1.setText(player1.getName());
        this.btnDraw2.setText(player2.getName());
        this.btnDraw1.setVisible(true);
        this.btnDraw2.setVisible(true);
        this.lblDrawDummy1.setVisible(true);
        this.lblDrawDummy2.setVisible(true);
        this.lblDrawCard2.setIcon(new ImageIcon("cards/purple.png"));
        this.lblDrawCard1.setIcon(new ImageIcon("cards/purple.png"));
        
    }
    
    private void deal(){
        System.out.println("Deck size: " + this.deck.size());
        while(!this.deck.isEmpty()){
            this.player1.addToDrawStack(this.deck.pop()); 
            this.player2.addToDrawStack((this.deck.pop()));
        }
        //dump();
        prepUIElements();
        System.out.println("Done dealing");
        player1.setCanPlay(true);
        player2.setCanPlay(true);
        turn = 1;
    }
    
    private void winCards(Player winner,boolean war){
        if(!war) Collections.sort(BOARD, new BoardNode());
        
        for (int i = 0; i < BOARD.size(); i++) {
            winner.addToDiscardStack(BOARD.get(i).getCard());
        }
        if(winner==player1){
            results+="h";
        }
        else{
            results+="c";
        }
        System.out.println(winner.getName() + " won the exchange!");
        this.BOARD=new ArrayList<>();
        System.out.println("----------------------------------");
    }
    
    private boolean hasLost(Player player){
        if(player.getDrawStack().isEmpty()){
            if(!player.getDiscardStack().isEmpty()){
                player.replenishDrawStack();
                return false;
            }
            return true;
        }
        return false;
    }
    
    private Player pickLoser(Player winner){
        if(winner==player1){
            return player2;
        }
        return player1;
    }
    
    private Stack<BoardNode> pickLoserStack(Stack<BoardNode> winner){
        if(winner==miniStackA){
            return miniStackB;
        }
        return miniStackA;
    }
    
    private void endTurn(Player winner){
        if(hasLost(pickLoser(winner))){
            turn=-1;
            victory(winner);
        }     
    }
    
    private void play(Player player){
        turn = -1;
        if(warMode){
            if(player==player1)turnWarA();
            else turnWarB();
        }
        else{
            player.setCanPlay(false);
            this.animPlayCard(player);
            BOARD.add(new BoardNode(player.draw(),player));
            Player winner = null;
            if(BOARD.size()==2){
                if(BOARD.get(0).getCard().getRank()>BOARD.get(1).getCard().getRank()){
                    winner = BOARD.get(0).getPlayer();
                }
                else if(BOARD.get(0).getCard().getRank()<BOARD.get(1).getCard().getRank()){
                    winner = BOARD.get(1).getPlayer();
                }
                else{
                    initWar();
                }

                if(winner!=null){
                    winCards(winner,false);
                    player1.setCanPlay(true);
                    player2.setCanPlay(true);
                    endTurn(winner);
                }
            } 
        }
        turn=1;
    }
    
    private void initWar(){
        warMode = true;
        warMult++;
        player1.setCanPlay(true);
        player2.setCanPlay(true);
        System.out.println("WAR!!");
        this.lblWAR.setVisible(true);
        if(this.BOARD.size()>0){
            miniStackA.push(new BoardNode(BOARD.get(0).getCard(),BOARD.get(0).getPlayer())); 
            miniStackB.push(new BoardNode(BOARD.get(1).getCard(),BOARD.get(1).getPlayer()));
            this.BOARD = new ArrayList<>(); //may cause errors
        }
    }
    
    private void victory(Player player){
        player1.setCanPlay(false);
        player2.setCanPlay(false);
        System.out.println(player.getName() + " WINS!");
        for (int i = 0; i < results.length(); i++) {
            System.out.println(i+1+": "+results.charAt(i));
            
        }
        
        this.gui.musicStop();
        this.gui.setMusicStatus(false);
        this.gui.getpMenu().changeButtonIconMute();
        this.gui.getpMatchSetup().changeButtonIconMute();
        this.gui.getpWar().changeButtonIconMute();
        //genRecord(player);
    }
    
    private void finishWar(char notifier){
        boolean proceed = false;
        if(notifier=='A') proceed = miniStackB.size()==4*warMult+1;
        if(notifier=='B') proceed = miniStackA.size()==4*warMult+1;
        
        if(proceed) {
            if(miniStackA.peek().getCard().getRank()==miniStackB.peek().getCard().getRank()){
                initWar();
            }
            else{
                warMult=0;
                this.lblWAR.setVisible(false);
                Stack<BoardNode> winnerStack = miniStackA.peek().getCard().getRank()>miniStackB.peek().getCard().getRank()? miniStackA : miniStackB;
                Stack<BoardNode> loserStack = pickLoserStack(winnerStack);
                BoardNode winnerNode = winnerStack.peek();
                loserStack.addAll(winnerStack);
                //miniStackA.addAll(miniStackB);
                this.BOARD = new ArrayList<>(loserStack);
                this.miniStackA = new Stack<>();
                this.miniStackB = new Stack<>();
                winCards(winnerNode.getPlayer(),true);
                this.warMode = false;
                player1.setCanPlay(true);
                player2.setCanPlay(true);
                endTurn(winnerNode.getPlayer());
                
            }
        }
    }
    
    private void turnWarA() throws EmptyStackException{
        try{
            if(miniStackA.size()<4*warMult+1){
                this.animPlayCard(player1);
                miniStackA.push(new BoardNode(player1.draw(),player1));
            
                if(miniStackA.size()==4*warMult+1){
                    player1.setCanPlay(false);
                    finishWar('A');
                }
        }   
        } catch(EmptyStackException e){
            victory(player2);
        }
        
    }
    
    private void turnWarB() throws EmptyStackException{ 
        try{
            if(miniStackB.size()<4*warMult+1){
                this.animPlayCard(player2);
            miniStackB.push(new BoardNode(player2.draw(),player2));
            
                if(miniStackB.size()==4*warMult+1){
                    player2.setCanPlay(false);
                    finishWar('B');
                }
            }
            
        } catch(EmptyStackException e){
            victory(player1);
        }
    }
    
    public void changeButtonIconMute(){
        this.musicButton.setIcon(new ImageIcon("music/mute.png"));     
    }
    
    public void changeButtonIconVolume(){
        this.musicButton.setIcon(new ImageIcon("music/volume.png"));       
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnDeal = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        lblWAR = new javax.swing.JLabel();
        btnDraw1 = new javax.swing.JButton();
        btnDraw2 = new javax.swing.JButton();
        lblDiscardDummy1 = new javax.swing.JLabel();
        lblDiscardDummy2 = new javax.swing.JLabel();
        lblTest3 = new javax.swing.JLabel();
        lblTest5 = new javax.swing.JLabel();
        lblDrawCard2 = new javax.swing.JLabel();
        lblDrawCard1 = new javax.swing.JLabel();
        lblDrawDummy1 = new javax.swing.JLabel();
        lblDrawDummy2 = new javax.swing.JLabel();
        musicButton = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1280, 720));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnDeal.setText("DEAL");
        btnDeal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDealActionPerformed(evt);
            }
        });
        add(btnDeal, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 300, -1, -1));

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 350, -1, -1));

        lblWAR.setText("WAR!");
        add(lblWAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 390, -1, -1));

        btnDraw1.setText("PLAY");
        btnDraw1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDraw1ActionPerformed(evt);
            }
        });
        add(btnDraw1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 570, -1, -1));

        btnDraw2.setText("PLAY2");
        btnDraw2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDraw2ActionPerformed(evt);
            }
        });
        add(btnDraw2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 620, -1, -1));

        lblDiscardDummy1.setText("DiscardDummy1");
        add(lblDiscardDummy1, new org.netbeans.lib.awtextra.AbsoluteConstraints(855, 490, 128, 178));

        lblDiscardDummy2.setText("DiscardDummy2");
        add(lblDiscardDummy2, new org.netbeans.lib.awtextra.AbsoluteConstraints(293, 20, 128, 178));

        lblTest3.setText("saddle");
        add(lblTest3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1126, 20, 128, 178));

        lblTest5.setText("saddle");
        add(lblTest5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 128, 178));

        lblDrawCard2.setText("DrawCard2");
        add(lblDrawCard2, new org.netbeans.lib.awtextra.AbsoluteConstraints(574, 20, 128, 178));

        lblDrawCard1.setText("DrawCard1");
        add(lblDrawCard1, new org.netbeans.lib.awtextra.AbsoluteConstraints(574, 490, 128, 178));

        lblDrawDummy1.setText("DrawDummy1");
        add(lblDrawDummy1, new org.netbeans.lib.awtextra.AbsoluteConstraints(574, 490, 128, 178));

        lblDrawDummy2.setText("DrawDummy2");
        add(lblDrawDummy2, new org.netbeans.lib.awtextra.AbsoluteConstraints(574, 20, 128, 178));

        musicButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                musicButtonActionPerformed(evt);
            }
        });
        add(musicButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 41, 40));
    }// </editor-fold>//GEN-END:initComponents

    private void btnDealActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDealActionPerformed
        deal();
    }//GEN-LAST:event_btnDealActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        System.out.print(player1.getName()+" : Draw : [");
        for (int i = 0; i < player1.getDrawStack().size(); i++) {
            System.out.print(player1.getDrawStack().get(i).getRank()+" , ");
        }
        System.out.print("] // Discard: [");
        for (int i = 0; i < player1.getDiscardStack().size(); i++) {
            System.out.print(player1.getDiscardStack().get(i).getRank()+" , ");
        }
        System.out.print("]");
        
        System.out.println("");
        
        System.out.print(player2.getName()+" : Draw : [");
        for (int i = 0; i < player2.getDrawStack().size(); i++) {
            System.out.print(player2.getDrawStack().get(i).getRank()+" , ");
        }
        System.out.print("] // Discard: [");
        for (int i = 0; i < player2.getDiscardStack().size(); i++) {
            System.out.print(player2.getDiscardStack().get(i).getRank()+" , ");
        }
        System.out.print("]");
        System.out.println("");
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnDraw1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDraw1ActionPerformed
        if(turn==1 && player1.canPlay()){
            play(player1);
            if(cpu){
                if(turn==1 && player2.canPlay()){
                    play(player2);
                }
                    
            }
        }
    }//GEN-LAST:event_btnDraw1ActionPerformed

    private void btnDraw2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDraw2ActionPerformed
        if(!cpu){
            if(turn==1 && player2.canPlay()){
            play(player2);
            }
        }        
    }//GEN-LAST:event_btnDraw2ActionPerformed

    private void musicButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_musicButtonActionPerformed
        if(this.gui.getMusicStatus() == true){
            this.gui.musicStop();
            this.gui.setMusicStatus(false);
            System.out.println(this.gui.getMusicStatus());
            this.changeButtonIconMute();
        }
        else{
            this.gui.musicPlay();
            this.gui.setMusicStatus(true);
            this.changeButtonIconVolume();
        }
    }//GEN-LAST:event_musicButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeal;
    private javax.swing.JButton btnDraw1;
    private javax.swing.JButton btnDraw2;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel lblDiscardDummy1;
    private javax.swing.JLabel lblDiscardDummy2;
    private javax.swing.JLabel lblDrawCard1;
    private javax.swing.JLabel lblDrawCard2;
    private javax.swing.JLabel lblDrawDummy1;
    private javax.swing.JLabel lblDrawDummy2;
    private javax.swing.JLabel lblTest3;
    private javax.swing.JLabel lblTest5;
    private javax.swing.JLabel lblWAR;
    private javax.swing.JButton musicButton;
    // End of variables declaration//GEN-END:variables
    
}
