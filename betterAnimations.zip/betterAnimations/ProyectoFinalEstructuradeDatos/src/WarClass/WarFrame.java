/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WarClass;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import sun.audio.*;
import ui.*;

public class WarFrame extends JFrame{
    private Container c;
    private CardLayout cardLay;
    private Menu pMenu;
    private Rules pRules;
    private Credits pCredits;
    private MatchSetup pMatchSetup;
    private TheWar pWar;
    private Music mu = new Music();
    private boolean musicStatus = true;
   
    public WarFrame() throws FileNotFoundException, IOException {//throws IOException{
        this.init();
        
    }
    
    public boolean getMusicStatus(){
        return musicStatus;
    }
    
    public void musicPlay(){       
        this.mu.setFile("music/military_music_wav(1).wav");
        this.mu.loop();
    }
    
    public void musicStop(){       
        this.mu.stop();
    }
    
    private void init(){// throws IOException{
        this.c=getContentPane();
        this.cardLay = new CardLayout();
        c.setLayout(cardLay);
        c.setSize(1280,720);
        this.initPanels();
        setSize(1280,720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }
    
    private void initPanels(){
        this.pMenu=new Menu(this);
        this.pRules=new Rules(this);
        this.pCredits = new Credits(this);
        this.pMatchSetup = new MatchSetup(this);
        
        this.musicPlay();
        c.add(getpMenu(),"menu");
        c.add(pRules,"rules");
        c.add(pCredits, "credits");
        c.add(getpMatchSetup(),"setup");
    }
    
    public void goToMenu(){
        cardLay.show(c, "menu");
    }
    public void goToRules(){
        cardLay.show(c, "rules");
    }
    public void goToCredits(){
        cardLay.show(c, "credits");
    }
    public void goToSetup(GameManager manager){
        this.getpMatchSetup().setManager(manager);
        cardLay.show(c, "setup");
    }
    
    public void goToWar(GameManager manager){
        this.pWar = new TheWar(this,manager);
        c.add(getpWar(),"war");
        cardLay.show(c, "war");
    }
    
    public void setMusicStatus(boolean musicStatus) {
        this.musicStatus = musicStatus;
    }

    /**
     * @return the pMenu
     */
    public Menu getpMenu() {
        return pMenu;
    }

    /**
     * @return the pMatchSetup
     */
    public MatchSetup getpMatchSetup() {
        return pMatchSetup;
    }

    /**
     * @return the pWar
     */
    public TheWar getpWar() {
        return pWar;
    }
}

    class Music {
        Clip clip;
        
        public void setFile(String path){
            try{
                File file = new File(path);
                AudioInputStream sound = AudioSystem.getAudioInputStream(file);
                clip = AudioSystem.getClip();
                clip.open(sound);
            }
            catch(IOException | LineUnavailableException | UnsupportedAudioFileException e){
                System.out.println("Fallo de sonido");
            }
        }
        
        public void play(){
            clip.setFramePosition(0);
            clip.start();
        }
        
        public void loop(){
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
        
        public void stop(){
            clip.stop();
            clip.close();
        }
    }