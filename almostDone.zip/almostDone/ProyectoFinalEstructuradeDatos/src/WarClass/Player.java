/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WarClass;

import java.util.Stack;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Player{
    private Stack<Card> discardStack , drawStack;
    private ImageIcon playerIcon;
    private String name;
    private boolean canPlay;
    private int drawnCards , wonWars , wonExchange;
    private Card lastDrawn;
    
    
    public Player(String name){
        this.name = name;
        this.initMatchAttributes();
        
    }
    
    public void initMatchAttributes(){
        this.discardStack = new Stack<>();
        this.drawStack = new Stack<>();
        this.canPlay = false;
        this.drawnCards = 0;
        this.wonWars = 0;
        this.wonExchange = 0;
        this.lastDrawn = null;
        
    }
    
    public int getDrawnCards(){
        return this.drawnCards;
    }
    
    public int getWonWars(){
        return this.wonWars;
    }
    
    public int getWonExchange(){
        return this.wonExchange;
    }
    
    
    public void addWonWars(){
        this.wonWars++;
    }
    
    public void addWonExchange(){
        this.wonExchange++;
    }
    
    public void setCanPlay(boolean canPlay){
        this.canPlay = canPlay;
    }
    
    public boolean canPlay(){
        return this.canPlay;
    }
    public void setName(String name){
        this.name = name;
    }
    
    public String getName(){
        return this.name;
    }
    
    public void setPlayerIcon(ImageIcon playerIcon){
        this.playerIcon = playerIcon;
    }
    
    public Stack<Card> getDrawStack(){
        return this.drawStack;
    }
    
    public Stack <Card> getDiscardStack(){
        return this.discardStack;
    }
    
    public Card draw(){
        if(!this.drawStack.isEmpty()){
            //System.out.println(this.name+": "+this.drawStack.peek().toString()+" added to the board.");
            this.lastDrawn = this.drawStack.peek();
            this.drawnCards++;
            return this.drawStack.pop();
        }
        replenishDrawStack();
        if(!this.drawStack.isEmpty()){
            //System.out.println(this.drawStack.peek().toString()+" added to the board.");
            this.lastDrawn = this.drawStack.peek();
            this.drawnCards++;
            return this.drawStack.pop();
        }
        return null;
        
    }
    
    public void discard(Card c){
        
    }
    
    public void addToDrawStack(Card card){
        this.drawStack.push(card);
    }
    
    public void addToDiscardStack(Card card){
        
        this.discardStack.push(card);
    }
    
    
    public boolean hasCards(){ //FIX
        return !this.drawStack.isEmpty();
    }
    
    public ImageIcon getPlayerIcon(){
        return this.playerIcon;
    }
    
    
    @Override
    public String toString(){
        return "";
    }
    
    public int manyCards(){
        return this.drawStack.size()+this.discardStack.size();
    }
    
    public void replenishDrawStack(){
        while(!this.discardStack.isEmpty()){
            this.drawStack.push(discardStack.pop());
        }
    }
    
}
