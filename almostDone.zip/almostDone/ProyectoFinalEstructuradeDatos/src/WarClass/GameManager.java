/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WarClass;

import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author Wislo
 */
public class GameManager {
    private WarFrame gui;
    private Player player1 , player2;
    private ArrayList<Player> players;
    private boolean cpu , halfDeck;
    private Deck deck;
    private ImageIcon board,cardBack;
    
    
    
    public GameManager(WarFrame gui){
        this.gui = gui;
        this.players = new ArrayList<>();
        this.player1 = new Player("Player 1");
        this.players.add(player1);
        this.player2 = new Player("Player 2");
        this.players.add(player2);
        this.cpu=false;
        this.halfDeck = false;
        this.board = new ImageIcon("board\\basic_green.png");
    }
    
    public GameManager(WarFrame gui, ImageIcon bg){ //WTF
        this.gui = gui;
        this.player1 = new Player("Player 1");
        this.player2 = new Player("Player 2");
        this.cpu=false;
        this.halfDeck = false;
        this.board = bg;
    }
    
    public void resetVariables(){
        for (Player player : players) {
            player.initMatchAttributes();
        }
        this.run();
    }
    
    public void setHalfDeck(boolean halfDeck){
        this.halfDeck = halfDeck;
    }
    
    public ImageIcon getBoard(){
        return this.board;
    }
    
    public Player getPlayer1(){
        return this.player1;
    }
    
    public Player getPlayer2(){
        return this.player2;
    }
    
    public void setCPU(boolean cpu){
        this.cpu = cpu;
    }
    
    public Deck getDeck(){
        return this.deck;
    }
    
    public boolean isCPU(){
        return this.cpu;
    }
    
    public void setCardBack(ImageIcon cardBack){
        this.cardBack = cardBack;
    }
    
    public ImageIcon getCardBack(){
        return this.cardBack;
    }
    
    public boolean isHalfDeck(){
        return this.halfDeck;
    }
    
    public void run(){
        //System.out.println("Game Starts");
        this.deck = new Deck(halfDeck);
        this.gui.goToWar(this);
        
    }
    
    
    
}
