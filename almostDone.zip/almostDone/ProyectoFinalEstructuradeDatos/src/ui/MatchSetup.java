/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import WarClass.GameManager;
import WarClass.WarFrame;
import java.awt.Graphics;
import java.util.ArrayList;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

/**
 *
 * @author Wislo
 */
public class MatchSetup extends javax.swing.JPanel {
    private WarFrame gui;
    private GameManager manager;
    private ArrayList<ImageIcon> playerIcons;
    private ArrayList<ImageIcon> cardBacks;
    private ImageIcon background;
    private ButtonGroup bg;
    private final int CARROUSEL_LIMIT;
    private int c1, c2;
    
    /**
     * Creates new form PlayerSetup
     */
    public MatchSetup(WarFrame gui) {
        initComponents();
        this.gui = gui;
        this.playerIcons = new ArrayList<>();
        this.cardBacks = new ArrayList<>();
        this.bg = new ButtonGroup();
        this.loadCardBacks();
        this.loadIcons();
        this.CARROUSEL_LIMIT = playerIcons.size()-1;
        this.c1 = 0;
        this.c2 = 0;
        this.showCardBacks();
        this.showIcons();
        this.addToBtnGroup();
        background = new ImageIcon("board\\war_background.png");
               
        if(this.gui.getMusicStatus() == true){
            this.changeButtonIconVolume();
        }
        else{
            this.changeButtonIconMute();
        }
    }
    
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(background.getImage(), 0, 0, this);
    }
    
    public void setManager(GameManager manager){
        this.manager = manager;
    }
    
    public void changeButtonIconMute(){
        this.musicButton.setIcon(new ImageIcon("music/mute.png"));     
    }
    
    public void changeButtonIconVolume(){
        this.musicButton.setIcon(new ImageIcon("music/volume.png"));       
    }
    
    public void setPreferences(){
        this.manager.getPlayer1().setName(this.tfInputName1.getText());
        this.manager.getPlayer2().setName(this.tfInputName2.getText());
        this.manager.getPlayer1().setPlayerIcon(this.playerIcons.get(c1));
        this.manager.getPlayer2().setPlayerIcon(this.playerIcons.get(c2));
        this.manager.setCardBack(retrieveCard());
        this.manager.setCPU(this.tbtnCPU.isSelected());
        this.manager.setHalfDeck(this.tbtnHalfDeck.isSelected());
        this.manager.run();
    }
    
    public void loadIcons(){
        this.playerIcons.add(new ImageIcon("playerIcons/zss.png"));
        this.playerIcons.add(new ImageIcon("playerIcons/falcon.png"));
        this.playerIcons.add(new ImageIcon("playerIcons/kim.png"));
        this.playerIcons.add(new ImageIcon("playerIcons/putin.png"));
        this.playerIcons.add(new ImageIcon("playerIcons/trump.png"));
        this.playerIcons.add(new ImageIcon("playerIcons/robot_red.png"));
        this.playerIcons.add(new ImageIcon("playerIcons/robot_blue.png"));
        
    }
    
    private void loadCardBacks(){
        this.cardBacks.add(new ImageIcon("cards/blue.png"));
        this.cardBacks.add(new ImageIcon("cards/gray.png"));
        this.cardBacks.add(new ImageIcon("cards/green.png"));
        this.cardBacks.add(new ImageIcon("cards/purple.png"));
        this.cardBacks.add(new ImageIcon("cards/red.png"));
        this.cardBacks.add(new ImageIcon("cards/yellow.png"));
    }
    
    private void showCardBacks(){
        this.lblCardBack0.setIcon(cardBacks.get(0));
        this.lblCardBack1.setIcon(cardBacks.get(1));
        this.lblCardBack2.setIcon(cardBacks.get(2));
        this.lblCardBack3.setIcon(cardBacks.get(3));
        this.lblCardBack4.setIcon(cardBacks.get(4));
        this.lblCardBack5.setIcon(cardBacks.get(5));
    }
    
    private void showIcons(){
        if(c1>CARROUSEL_LIMIT) c1=0;
        if(c1<0) c1 = CARROUSEL_LIMIT;
        
        if(c2>CARROUSEL_LIMIT) c2=0;
        if(c2<0) c2 = CARROUSEL_LIMIT;
        
        this.lblIcon1.setIcon(playerIcons.get(c1));
        this.lblIcon2.setIcon(playerIcons.get(c2));
    }
    
    
    
    private ImageIcon retrieveCard(){
        if(rbtn0.isSelected()) return this.cardBacks.get(0);
        if(rbtn1.isSelected()) return this.cardBacks.get(1);
        if(rbtn2.isSelected()) return this.cardBacks.get(2);
        if(rbtn3.isSelected()) return this.cardBacks.get(3);
        if(rbtn4.isSelected()) return this.cardBacks.get(4);
        if(rbtn5.isSelected()) return this.cardBacks.get(5);
         
        return this.cardBacks.get(4); 
    }
    
    private void addToBtnGroup(){
        this.bg.add(rbtn0);
        this.bg.add(rbtn1);
        this.bg.add(rbtn2);
        this.bg.add(rbtn3);
        this.bg.add(rbtn4);
        this.bg.add(rbtn5);
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnBackc1 = new javax.swing.JButton();
        tfInputName1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        tbtnCPU = new javax.swing.JToggleButton();
        jLabel4 = new javax.swing.JLabel();
        btnBackc2 = new javax.swing.JButton();
        btnNextC1 = new javax.swing.JButton();
        btnNextc2 = new javax.swing.JButton();
        tfInputName2 = new javax.swing.JTextField();
        tbtnHalfDeck = new javax.swing.JToggleButton();
        lblCardBack1 = new javax.swing.JLabel();
        lblCardBack3 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        lblCardBack2 = new javax.swing.JLabel();
        lblIcon2 = new javax.swing.JLabel();
        lblIcon1 = new javax.swing.JLabel();
        lblCardBack5 = new javax.swing.JLabel();
        lblCardBack4 = new javax.swing.JLabel();
        lblCardBack0 = new javax.swing.JLabel();
        btnWar = new javax.swing.JButton();
        musicButton = new javax.swing.JButton();
        rbtn0 = new javax.swing.JRadioButton();
        rbtn1 = new javax.swing.JRadioButton();
        rbtn2 = new javax.swing.JRadioButton();
        rbtn3 = new javax.swing.JRadioButton();
        rbtn4 = new javax.swing.JRadioButton();
        rbtn5 = new javax.swing.JRadioButton();

        setMaximumSize(new java.awt.Dimension(1280, 720));
        setPreferredSize(new java.awt.Dimension(1280, 720));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBackc1.setText("<");
        btnBackc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackc1ActionPerformed(evt);
            }
        });
        add(btnBackc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 150, -1, -1));

        tfInputName1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tfInputName1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tfInputName1.setText("Player 1");
        tfInputName1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfInputName1ActionPerformed(evt);
            }
        });
        add(tfInputName1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, 230, 30));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Configure match preferences:");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(505, 30, 270, -1));

        tbtnCPU.setText("CPU");
        add(tbtnCPU, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 70, 110, 59));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Pick a deck style:");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(571, 330, 140, 30));

        btnBackc2.setText("<");
        btnBackc2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackc2ActionPerformed(evt);
            }
        });
        add(btnBackc2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 150, -1, -1));

        btnNextC1.setText(">");
        btnNextC1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextC1ActionPerformed(evt);
            }
        });
        add(btnNextC1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 150, -1, -1));

        btnNextc2.setText(">");
        btnNextc2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextc2ActionPerformed(evt);
            }
        });
        add(btnNextc2, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 140, -1, -1));

        tfInputName2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tfInputName2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tfInputName2.setText("Player 2");
        tfInputName2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfInputName2ActionPerformed(evt);
            }
        });
        add(tfInputName2, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 280, 230, 30));

        tbtnHalfDeck.setText("Half - deck");
        tbtnHalfDeck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbtnHalfDeckActionPerformed(evt);
            }
        });
        add(tbtnHalfDeck, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 190, 110, -1));

        lblCardBack1.setText("cardBack1");
        add(lblCardBack1, new org.netbeans.lib.awtextra.AbsoluteConstraints(256, 380, 128, 178));

        lblCardBack3.setText("cardBack3");
        add(lblCardBack3, new org.netbeans.lib.awtextra.AbsoluteConstraints(682, 380, 128, 178));

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 610, 104, 39));

        lblCardBack2.setText("cardBack2");
        add(lblCardBack2, new org.netbeans.lib.awtextra.AbsoluteConstraints(469, 380, 128, 178));

        lblIcon2.setText("playerIcon2");
        add(lblIcon2, new org.netbeans.lib.awtextra.AbsoluteConstraints(804, 80, 128, 178));

        lblIcon1.setText("playerIcon1");
        add(lblIcon1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 80, 128, 178));

        lblCardBack5.setText("cardBack5");
        add(lblCardBack5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1108, 380, 128, 178));

        lblCardBack4.setText("cardBack4");
        add(lblCardBack4, new org.netbeans.lib.awtextra.AbsoluteConstraints(895, 380, 128, 178));

        lblCardBack0.setText("cardBack0");
        add(lblCardBack0, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 380, 128, 178));

        btnWar.setText("WAR!");
        btnWar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWarActionPerformed(evt);
            }
        });
        add(btnWar, new org.netbeans.lib.awtextra.AbsoluteConstraints(568, 615, 144, 60));

        musicButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                musicButtonActionPerformed(evt);
            }
        });
        add(musicButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 630, 41, 40));

        rbtn0.setOpaque(false);
        add(rbtn0, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 570, 20, -1));

        rbtn1.setOpaque(false);
        add(rbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(309, 570, -1, -1));

        rbtn2.setOpaque(false);
        add(rbtn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(522, 570, -1, -1));

        rbtn3.setOpaque(false);
        add(rbtn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(735, 570, -1, -1));

        rbtn4.setOpaque(false);
        add(rbtn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(948, 570, -1, -1));

        rbtn5.setOpaque(false);
        add(rbtn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1161, 570, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.gui.goToMenu();
        if(this.gui.getMusicStatus() == true){
            this.gui.getpMenu().changeButtonIconVolume();
        }
        else{
            this.gui.getpMenu().changeButtonIconMute();
        }
    }//GEN-LAST:event_btnBackActionPerformed

    private void tfInputName2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfInputName2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfInputName2ActionPerformed

    private void tfInputName1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfInputName1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfInputName1ActionPerformed

    private void btnBackc1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackc1ActionPerformed
        this.c1--;
        this.showIcons();
    }//GEN-LAST:event_btnBackc1ActionPerformed

    private void btnBackc2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackc2ActionPerformed
        this.c2--;
        this.showIcons();
    }//GEN-LAST:event_btnBackc2ActionPerformed

    private void btnWarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWarActionPerformed
        setPreferences();
        if(this.gui.getMusicStatus() == true){
            this.gui.getpWar().changeButtonIconVolume();
        }
        else{
            this.gui.getpWar().changeButtonIconMute();
        }
    }//GEN-LAST:event_btnWarActionPerformed

    private void tbtnHalfDeckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbtnHalfDeckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tbtnHalfDeckActionPerformed

    private void musicButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_musicButtonActionPerformed
        if(this.gui.getMusicStatus() == true){
            this.gui.musicStop();
            this.gui.setMusicStatus(false);
            this.changeButtonIconMute();
        }
        else{
            this.gui.musicPlay();
            this.gui.setMusicStatus(true);
            this.changeButtonIconVolume();
        }
    }//GEN-LAST:event_musicButtonActionPerformed

    private void btnNextC1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextC1ActionPerformed
        this.c1++;
        this.showIcons();
    }//GEN-LAST:event_btnNextC1ActionPerformed

    private void btnNextc2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextc2ActionPerformed
        this.c2++;
        this.showIcons();
    }//GEN-LAST:event_btnNextc2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBackc1;
    private javax.swing.JButton btnBackc2;
    private javax.swing.JButton btnNextC1;
    private javax.swing.JButton btnNextc2;
    private javax.swing.JButton btnWar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lblCardBack0;
    private javax.swing.JLabel lblCardBack1;
    private javax.swing.JLabel lblCardBack2;
    private javax.swing.JLabel lblCardBack3;
    private javax.swing.JLabel lblCardBack4;
    private javax.swing.JLabel lblCardBack5;
    private javax.swing.JLabel lblIcon1;
    private javax.swing.JLabel lblIcon2;
    private javax.swing.JButton musicButton;
    private javax.swing.JRadioButton rbtn0;
    private javax.swing.JRadioButton rbtn1;
    private javax.swing.JRadioButton rbtn2;
    private javax.swing.JRadioButton rbtn3;
    private javax.swing.JRadioButton rbtn4;
    private javax.swing.JRadioButton rbtn5;
    private javax.swing.JToggleButton tbtnCPU;
    private javax.swing.JToggleButton tbtnHalfDeck;
    private javax.swing.JTextField tfInputName1;
    private javax.swing.JTextField tfInputName2;
    // End of variables declaration//GEN-END:variables

    /**
     * @return the musicButton
     */
    public javax.swing.JButton getMusicButton() {
        return musicButton;
    }

    /**
     * @param musicButton the musicButton to set
     */
    public void setMusicButton(javax.swing.JButton musicButton) {
        this.musicButton = musicButton;
    }
}
